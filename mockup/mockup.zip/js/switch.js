// JavaScript Document
$(".switch-item").click(function() {
	$(".switch-item").removeClass("switch-selected");
	$(this).addClass("switch-selected");
});
