// JavaScript Document
$("#btn-invite").click(function() {
	$("#mask-dialog").show();
});