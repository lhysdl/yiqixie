// JavaScript Document
$("#btn-ok").click(function() {
	$("#mask-qrcode").show();
});