// JavaScript Document
$(".ebtn").click(function() {
	$(this).toggleClass("ebtn-on");
});